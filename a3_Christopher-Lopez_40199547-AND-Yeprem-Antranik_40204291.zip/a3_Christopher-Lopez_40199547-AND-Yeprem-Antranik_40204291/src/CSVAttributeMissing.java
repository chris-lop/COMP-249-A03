/**
 * 
 * @author Christopher Lopez 40199547 and Yeprem Antranik 40204291
 *COMP 249
 *Assignment 3
 *This exception class CSVAttributeMissing targets all 
 *errors related to an attribute missing in the file
 *03/25/2022
 */
public class CSVAttributeMissing extends Exception {
	
	/**
	 * Constructor with a message when that error occurs
	 */
	public CSVAttributeMissing() {
		super("Error: Input row cannot be parsed due to missing information");
	}

	/**
	 * Constructor that takes a String parameter
	 * @param aString a variable
	 */
	public CSVAttributeMissing(String aString) {
		super(aString);
	}

	/**
	 * Retrieve the message
	 */
	public String getMessage() {
		return super.getMessage();
	}
}
