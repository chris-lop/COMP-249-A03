/**
 * 
 * @author Christopher Lopez 40199547 and Yeprem Antranik 40204291
 *COMP 249
 *Assignment 3
 *This exception class CSVDataMissing targets all 
 *errors related to a data missing in the file
 *03/25/2022
 */
public class CSVDataMissing extends Exception {
	
	/**
	 * Constructor with a message when that error occurs
	 */
	public CSVDataMissing() {
		super("Error: Input row cannot be parsed due to missing information");
	}

	/**
	 * Constructor that takes a String parameter
	 * @param aString a variable
	 */
	public CSVDataMissing(String aString) {
		super(aString);
	}

	/**
	 * Retrieve the message
	 */
	public String getMessage() {
		return super.getMessage();
	}
}
